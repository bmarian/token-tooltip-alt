import Settings from "./Settings.js";
import Utils from "./Utils.js";
class Init {
    constructor() {
    }
    static getInstance() {
        if (!Init._instance)
            Init._instance = new Init();
        return Init._instance;
    }
    _loadTemplates() {
        return loadTemplates(Settings.templatePaths);
    }
    async initHook() {
        Settings.registerSettings();
        await this._loadTemplates();
        Utils.debug('Module initialized.', false);
    }
    async canvasInitHook() {
        const tooltipContainer = $(`<div class="${Utils.moduleName}-tooltip-container hidden"></div>`);
        $('.game').append(tooltipContainer);
    }
}
export default Init.getInstance();
