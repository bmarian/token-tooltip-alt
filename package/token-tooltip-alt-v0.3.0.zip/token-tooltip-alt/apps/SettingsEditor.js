import Utils from "../module/Utils.js";
import Settings from "../module/Settings.js";
export default class SettingsEditor extends FormApplication {
    static get defaultOptions() {
        return {
            ...super.defaultOptions,
            title: 'Settings Editor',
            template: `modules/${Utils.moduleName}/templates/settings-editor.hbs`,
            width: 600,
            submitOnChange: false,
            submitOnClose: true,
            closeOnSubmit: true,
            resizable: true,
        };
    }
    _prepareListForDisplay() {
        return Settings.getSetting(Settings.settingKeys.TOOLTIP_ITEMS) || [];
    }
    _deleteClick() {
        $(this).closest(`.${Utils.moduleName}-row`).remove();
    }
    async _addClick() {
        const $tbody = $(this)?.parent()?.parent()?.find('tbody');
        const $rows = $tbody.find(`.${Utils.moduleName}-row`);
        const lastIndex = $rows.length ? parseInt($rows.last().attr('index')) || 0 : 0;
        // TODO: If you delete everything and add a new item it will start the count from 1... it doesn't matter at all but just to remember this later
        const data = {
            moduleName: Utils.moduleName,
            index: lastIndex + 1,
        };
        const $newRow = $(await renderTemplate(Settings.templatePaths[1], data));
        $tbody.append($newRow);
        // TODO: Make this... not so bad... maybe...
        $newRow.find(`.${Utils.moduleName}-row_button.delete`).on('click', () => {
            $tbody.find(`.${Utils.moduleName}-row[index=${lastIndex + 1}]`).remove();
        });
    }
    getData(options) {
        return {
            options: this.options,
            moduleName: Utils.moduleName,
            tooltipItems: this._prepareListForDisplay(),
        };
    }
    async _updateObject(event, formData) {
        const { value, icon, expression, isNumber, color } = expandObject(formData);
        if (!(value && icon && expression))
            return;
        const tooltipItems = [];
        for (let key in value) {
            if (!value.hasOwnProperty(key))
                continue;
            const v = value[key];
            if (!v)
                continue;
            const i = icon[key];
            const e = expression[key];
            const n = isNumber[key];
            const c = color[key];
            tooltipItems.push({ value: v, icon: i, expression: e, isNumber: n, color: c });
        }
        Utils.debug(tooltipItems);
        return Settings.setSetting('tooltipItems', tooltipItems);
    }
    activateListeners($html) {
        super.activateListeners($html);
        $html.find(`.${Utils.moduleName}-row_button.delete`).on('click', this._deleteClick);
        $html.find(`.${Utils.moduleName}-footer_button.add`).on('click', this._addClick);
    }
}
