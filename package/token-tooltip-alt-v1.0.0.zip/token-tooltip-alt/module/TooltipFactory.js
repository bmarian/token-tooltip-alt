import Tooltip from "./Tooltip.js";
import Settings from "./Settings.js";
class TooltipFactory {
    constructor() {
        this._tooltips = [];
    }
    static getInstance() {
        if (!TooltipFactory._instance)
            TooltipFactory._instance = new TooltipFactory();
        return TooltipFactory._instance;
    }
    // get a value from Settings
    _getSetting(setting) {
        return Settings.getSetting(setting);
    }
    // get the positioning from settings, and if surprise pick a random possible position
    _getWhere() {
        let where = this._getSetting(Settings.settingKeys.TOOLTIP_POSITION) || 'right';
        if (where === 'surprise') {
            where = Settings.tooltipPositions[Math.floor(Math.random() * Settings.tooltipPositions.length)];
        }
        return where;
    }
    // create an array of data needed to initialize a tooltip
    _getTooltipData(token) {
        return [
            token,
            this._getSetting(Settings.settingKeys.DARK_THEME) ? 'dark' : '',
            Settings.getSystemSpecificClass(),
            this._getSetting(Settings.settingKeys.FONT_SIZE) || '1rem',
            this._getWhere(),
            'none',
            200,
            this._getSetting(Settings.settingKeys.DATA_SOURCE) || '',
            this._getSetting(Settings.settingKeys.TOOLTIP_VISIBILITY) || 'gm',
            Settings.templatePaths[0],
            $('.game'),
        ];
    }
    // get settings for <ALT>
    _getAltSettings() {
        return {
            showOnAlt: this._getSetting(Settings.settingKeys.SHOW_ALL_ON_ALT),
            showAllOnAlt: this._getSetting(Settings.settingKeys.SHOW_TOOLTIP_FOR_HIDDEN_TOKENS),
        };
    }
    // generates a tooltip if that token doesn't have one and adds it to the array, and shows it
    _addTooltip(token) {
        for (let i = 0; i < this._tooltips.length; i++) {
            const t = this._tooltips[i];
            if (t.getTokenId() === token?.id)
                return null;
        }
        const tooltip = new Tooltip(...this._getTooltipData(token));
        this._tooltips.push(tooltip);
        tooltip.show();
    }
    // generates a tooltip if that token doesn't have one and adds it to the array, and shows it
    _removeTooltip(token) {
        for (let i = 0; i < this._tooltips.length; i++) {
            const t = this._tooltips[i];
            if (t.getTokenId() === token?.id) {
                t.hide();
                this._tooltips.splice(i, 1);
                break;
            }
        }
    }
    // removes all the tooltips and destroys the objects
    _removeTooltips() {
        while (this._tooltips.length > 0) {
            this._tooltips.pop().hide();
        }
    }
    // public hook when hovering over a token (more precise when a token is focused)
    async hoverToken(token, isHovering) {
        if (!token?.actor)
            return;
        this[isHovering ? '_addTooltip' : '_removeTooltip'](token);
    }
    // public hook to remove all tooltips
    removeTooltips() {
        this._removeTooltips();
    }
}
export default TooltipFactory.getInstance();
