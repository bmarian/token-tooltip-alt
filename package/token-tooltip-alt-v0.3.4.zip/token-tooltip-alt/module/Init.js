import Settings from "./Settings.js";
import Utils from "./Utils.js";
import TooltipHandler from "./TooltipHandler.js";
class Init {
    constructor() {
    }
    static getInstance() {
        if (!Init._instance)
            Init._instance = new Init();
        return Init._instance;
    }
    _loadTemplates() {
        return loadTemplates(Settings.templatePaths);
    }
    async initHook() {
        Settings.registerSettings();
        await this._loadTemplates();
        Utils.debug('Module initialized.', false);
    }
    async canvasInitHook() {
        const systemClass = Settings.getSystemSpecificClass();
        const darkClass = Settings.getSetting(Settings.settingKeys.DARK_THEME) ? 'dark' : '';
        const tooltipContainer = $(`<div class="${Utils.moduleName}-tooltip-container ${systemClass} ${darkClass} hidden"></div>`);
        $('.game').append(tooltipContainer);
        $(window).on('blur', TooltipHandler.hideTooltipOnHook.bind(TooltipHandler));
    }
}
export default Init.getInstance();
