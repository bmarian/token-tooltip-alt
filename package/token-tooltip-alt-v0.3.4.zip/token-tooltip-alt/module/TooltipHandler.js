import Settings from "./Settings.js";
import Utils from "./Utils.js";
import stringMath from "../lib/MathEngine.js";
class TooltipHandler {
    constructor() {
        this._tooltipContainer = null;
        this._visibilityTypes = { FULL: 'full', PARTIAL: 'partial', NONE: 'none' };
        this._altTooltipContainers = [];
        this._wasTabDown = false;
        this._strictPathExp = new RegExp(/^(\w+\.)+(\w+)$/);
    }
    static getInstance() {
        if (!TooltipHandler._instance)
            TooltipHandler._instance = new TooltipHandler();
        return TooltipHandler._instance;
    }
    _initializeContainer() {
        if (!this._tooltipContainer) {
            this._tooltipContainer = $(`.${Utils.moduleName}-tooltip-container`);
            this._tooltipContainer.css('fontSize', Settings.getSetting(Settings.settingKeys.FONT_SIZE) || '1rem');
        }
        return this._tooltipContainer;
    }
    _toggleContainer(show) {
        this._tooltipContainer[show ? 'removeClass' : 'addClass']('hidden');
    }
    _clearContainer() {
        this._tooltipContainer.empty();
    }
    _clearAltContainers() {
        this._wasTabDown = false;
        while (this._altTooltipContainers.length > 0) {
            const tooltipContainer = this._altTooltipContainers.pop();
            tooltipContainer.remove();
        }
    }
    _appendToContainer(content) {
        this._clearContainer();
        this._tooltipContainer.html(content);
    }
    _getTooltipPosition(token, tooltipContainer) {
        let where = Settings.getSetting(Settings.settingKeys.TOOLTIP_POSITION);
        const tokenWT = token.worldTransform;
        const padding = 5;
        const leftTopPadding = 20;
        const position = {
            zIndex: token.zIndex,
            color: Settings.getSetting(Settings.settingKeys.ACCENT_COLOR)
        };
        if (where === 'surprise') {
            where = Settings.tooltipPositions[Math.floor(Math.random() * Settings.tooltipPositions.length)];
        }
        switch (where) {
            case 'right': {
                position['top'] = tokenWT.ty - padding;
                position['left'] = tokenWT.tx + (token.w * tokenWT.a) + padding;
                break;
            }
            case 'bottom': {
                position['top'] = tokenWT.ty + (token.h * tokenWT.a) + padding;
                position['left'] = tokenWT.tx - padding;
                break;
            }
            case 'left': {
                const cW = tooltipContainer.width();
                position['top'] = tokenWT.ty - padding;
                position['left'] = tokenWT.tx - cW - leftTopPadding;
                break;
            }
            case 'top': {
                const cH = tooltipContainer.height();
                position['top'] = tokenWT.ty - cH - leftTopPadding;
                position['left'] = tokenWT.tx - padding;
                break;
            }
        }
        return position;
    }
    // TODO: See if there is an efficient solution to check if tokens are in view
    _checkIfTokenInView(token) {
        return true;
    }
    _positionTooltip(tooltipContainer, token) {
        const position = this._getTooltipPosition(token, tooltipContainer);
        tooltipContainer.css(position);
    }
    _extractNumber(value) {
        const parsedValue = parseFloat(value);
        return isNaN(parsedValue) ? null : parsedValue;
    }
    _appendSimpleStat(value, item, statsArray) {
        if (typeof value !== 'string' && isNaN(value))
            return;
        const v = item.isNumber ? this._extractNumber(value) : value;
        statsArray.push({ value: v, icon: item?.icon, color: item?.color });
    }
    _appendObjectStat(values, item, statsArray) {
        if (!(isNaN(values.value) && isNaN(values.max))) {
            const temp = values.temp > 0 ? `(${values.temp})` : '';
            const tempmax = values.tempmax > 0 ? `(${values.tempmax})` : '';
            const value = `${values.value}${temp}/${values.max}${tempmax}`;
            statsArray.push({ value, icon: item?.icon, color: item?.color });
        }
    }
    _appendStat(item, value, statsArray) {
        if (!(item && value && statsArray))
            return;
        if (typeof value === 'object') {
            this._appendObjectStat({
                value: this._extractNumber(value.value),
                max: this._extractNumber(value.max),
                temp: this._extractNumber(value.temp),
                tempmax: this._extractNumber(value.tempmax),
            }, item, statsArray);
        }
        else {
            this._appendSimpleStat(value, item, statsArray);
        }
    }
    _getNestedData(data, path) {
        if (!this._strictPathExp.test(path))
            return null;
        const paths = path.split('.');
        if (!paths.length)
            return null;
        let res = data;
        for (let i = 0; i < paths.length; i++) {
            res = res?.[paths[i]];
        }
        return res;
    }
    _handleOperations(data, operation) {
        const th = this;
        const o = operation.replace(/([^\d\W]+\.)+([^\d\W]+)/g, (dataPath) => {
            return th._extractNumber(th._getNestedData(data, dataPath));
        });
        return stringMath(o);
    }
    _expressionHandler(data, expression) {
        const th = this;
        return expression.replace(/{([^}]*)}/g, (_0, dataPath) => {
            const value = th[th._strictPathExp.test(dataPath) ? '_getNestedData' : '_handleOperations'](data, dataPath);
            // The explicit check is needed for values that have 0;
            return value !== null ? value : '';
        });
    }
    _getTooltipData(token, visibilityType) {
        const stats = [];
        const data = token?.actor?.data?.data;
        const isVisibilityFull = visibilityType === this._visibilityTypes.FULL;
        const useAccentColor = Settings.getSetting(Settings.settingKeys.USE_ACCENT_COLOR_FOR_EVERYTHING);
        const exceptionValue = Settings.getSetting(Settings.settingKeys.DONT_SHOW);
        const itemList = isVisibilityFull ?
            Settings.getSetting(Settings.settingKeys.TOOLTIP_ITEMS) : Settings.getSetting(Settings.settingKeys.HOSTILE_ITEMS);
        for (let i = 0; i < itemList.length; i++) {
            const item = itemList[i];
            const value = item?.expression ? this._expressionHandler(data, item?.value) : this._getNestedData(data, item?.value);
            if (exceptionValue !== '' && value?.toString() === exceptionValue)
                return { stats: [] };
            if (useAccentColor)
                item.color = Settings.getSetting(Settings.settingKeys.ACCENT_COLOR);
            this._appendStat(item, value, stats);
        }
        const showTokenName = Settings.getSetting(Settings.settingKeys.DISPLAY_NAMES_IN_TOOLTIP) && isVisibilityFull;
        const tokenName = showTokenName ? token?.data?.name : null;
        if (isVisibilityFull)
            Utils.debug({ tokenName, data });
        return { moduleName: Utils.moduleName, stats, tokenName };
    }
    _typeToShow(token) {
        const visibility = Settings.getSetting(Settings.settingKeys.TOOLTIP_VISIBILITY);
        if (game?.user?.isGM)
            return this._visibilityTypes.FULL;
        if (visibility !== 'gm') {
            if (token?.actor?.owner)
                return this._visibilityTypes.FULL;
            const isFriendly = token?.data?.disposition === CONST?.TOKEN_DISPOSITIONS?.FRIENDLY;
            const isObservable = token?.actor?.permission === CONST?.ENTITY_PERMISSIONS?.OBSERVER;
            if ((isFriendly || isObservable) && (visibility === 'friendly' || visibility === 'all'))
                return this._visibilityTypes.FULL;
            if (visibility === 'all')
                return this._visibilityTypes.PARTIAL;
        }
        return this._visibilityTypes.NONE;
    }
    _hideTooltip() {
        this._initializeContainer();
        this._clearContainer();
        this._toggleContainer(false);
    }
    _appendAltTooltipContainer(tooltipHTML) {
        const systemClass = Settings.getSystemSpecificClass();
        const darkClass = Settings.getSetting(Settings.settingKeys.DARK_THEME) ? 'dark' : '';
        const tooltipContainer = $(`<div class="${Utils.moduleName}-tooltip-container ${systemClass} ${darkClass}"></div>`);
        tooltipContainer.css('fontSize', Settings.getSetting(Settings.settingKeys.FONT_SIZE) || '1rem');
        tooltipContainer.append(tooltipHTML);
        $('.game').append(tooltipContainer);
        return tooltipContainer;
    }
    async _getTooltipHTML(token) {
        const visibilityType = this._typeToShow(token);
        if (visibilityType === this._visibilityTypes.NONE)
            return null;
        const tooltipData = this._getTooltipData(token, visibilityType);
        if (!tooltipData.stats.length)
            return;
        return await renderTemplate(Settings.templatePaths[0], tooltipData);
    }
    async _handleTooltip(token, isHovering) {
        this._initializeContainer();
        if (!isHovering) {
            this._clearContainer();
            this._toggleContainer(false);
            return;
        }
        const tooltipHTML = await this._getTooltipHTML(token);
        if (!tooltipHTML)
            return;
        this._appendToContainer(tooltipHTML);
        this._toggleContainer(true);
        this._positionTooltip(this._tooltipContainer, token);
    }
    async _handleAltTooltips(token, isHovering) {
        if (!isHovering)
            return;
        const tooltipHTML = await this._getTooltipHTML(token);
        if (!tooltipHTML)
            return;
        const tooltipContainer = this._appendAltTooltipContainer(tooltipHTML);
        this._positionTooltip(tooltipContainer, token);
        this._altTooltipContainers.push(tooltipContainer);
    }
    async hoverTokenHook(token, isHovering) {
        if (!token?.actor || !this._checkIfTokenInView(token))
            return;
        const isAltPressed = keyboard?.isDown('Alt');
        if (!isAltPressed && !this._wasTabDown) {
            return this._handleTooltip(token, isHovering);
        }
        const allowShowAlt = Settings.getSetting(Settings.settingKeys.SHOW_ALL_ON_ALT);
        const showTooltipForHiddenTokens = Settings.getSetting(Settings.settingKeys.SHOW_TOOLTIP_FOR_HIDDEN_TOKENS);
        const isTokenHidden = token?.data?.hidden;
        if (!allowShowAlt || (isTokenHidden && !showTooltipForHiddenTokens))
            return;
        if (!isAltPressed) {
            return this._clearAltContainers();
        }
        if (isAltPressed) {
            this._wasTabDown = true;
            return this._handleAltTooltips(token, isHovering);
        }
    }
    hideTooltipOnHook() {
        this._hideTooltip();
        this._clearAltContainers();
    }
}
export default TooltipHandler.getInstance();
