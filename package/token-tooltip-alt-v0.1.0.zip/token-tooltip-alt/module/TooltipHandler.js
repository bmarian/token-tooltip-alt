import Settings from "./Settings.js";
import Utils from "./Utils.js";
class TooltipHandler {
    constructor() {
        this._tooltipContainer = null;
        this._visibilityTypes = { FULL: 'full', PARTIAL: 'partial', NONE: 'none' };
        this._altTooltipContainers = [];
        this._wasTabDown = false;
    }
    static getInstance() {
        if (!TooltipHandler._instance)
            TooltipHandler._instance = new TooltipHandler();
        return TooltipHandler._instance;
    }
    _initializeContainer() {
        if (!this._tooltipContainer)
            this._tooltipContainer = $(`.${Utils.moduleName}-tooltip-container`);
        return this._tooltipContainer;
    }
    _toggleContainer(show) {
        this._tooltipContainer[show ? 'removeClass' : 'addClass']('hidden');
    }
    _clearContainer() {
        this._tooltipContainer.empty();
    }
    _clearAltContainers() {
        this._wasTabDown = false;
        while (this._altTooltipContainers.length > 0) {
            const tooltipContainer = this._altTooltipContainers.pop();
            tooltipContainer.remove();
        }
    }
    _appendToContainer(content) {
        this._clearContainer();
        this._tooltipContainer.html(content);
    }
    _getTooltipPosition(token) {
        const tokenWT = token.worldTransform;
        return {
            left: tokenWT.tx + (token.width * tokenWT.a),
            // -5 comes from the token border when hovering, just makes the tooltip look nicer
            top: tokenWT.ty - 5,
            zIndex: token.zIndex,
            // Some extra styling to make it look nicer
            // @ts-ignore
            color: game?.user?.color,
        };
    }
    _positionTooltip(tooltipContainer, token) {
        const position = this._getTooltipPosition(token);
        tooltipContainer.css(position);
    }
    _appendSimpleStat(value, icon, statsArray) {
        if (typeof value !== 'string' && isNaN(value))
            return;
        statsArray.push({ value: `${value}`, icon });
    }
    _appendObjectStat(values, icon, statsArray) {
        if (!(isNaN(values.value) && isNaN(values.max))) {
            const temp = values.temp > 0 ? `(${values.temp})` : '';
            const tempmax = values.tempmax > 0 ? `(${values.tempmax})` : '';
            const value = `${values.value}${temp}/${values.max}${tempmax}`;
            statsArray.push({ value, icon });
        }
    }
    _appendStat(item, value, statsArray) {
        if (!(item && value && statsArray))
            return;
        if (typeof value === 'object') {
            this._appendObjectStat({
                value: parseInt(value.value),
                max: parseInt(value.max),
                temp: parseInt(value.temp) || 0,
                tempmax: parseInt(value.tempmax) || 0,
            }, item.icon, statsArray);
        }
        else {
            this._appendSimpleStat(value, item.icon, statsArray);
        }
    }
    _getNestedData(data, path) {
        const reg = new RegExp(/^(\w+\.)+(\w+)$/);
        if (!reg.test(path))
            return null;
        const paths = path.split('.');
        if (!paths.length)
            return null;
        let res = data;
        for (let i = 0; i < paths.length; i++) {
            res = res?.[paths[i]];
        }
        return res;
    }
    _getTooltipData(token, visibilityType) {
        const stats = [];
        const data = token?.actor?.data?.data;
        const tooltipItems = Settings.getSetting('tooltipItems') || [];
        for (let i = 0; i < tooltipItems.length; i++) {
            if (i > 1 && visibilityType !== this._visibilityTypes.FULL)
                break;
            const item = tooltipItems[i];
            this._appendStat(item, this._getNestedData(data, item?.value), stats);
        }
        Utils.debug(data);
        return { moduleName: Utils.moduleName, stats };
    }
    _typeToShow(token) {
        const visibility = Settings.getSetting('tooltipVisibility');
        if (game?.user?.isGM)
            return this._visibilityTypes.FULL;
        if (visibility !== 'gm') {
            if (token?.actor?.owner)
                return this._visibilityTypes.FULL;
            const isFriendly = token?.data?.disposition === CONST?.TOKEN_DISPOSITIONS?.FRIENDLY;
            const isObservable = token?.actor?.permission === CONST?.ENTITY_PERMISSIONS?.OBSERVER;
            if ((isFriendly || isObservable) && (visibility === 'friendly' || visibility === 'all'))
                return this._visibilityTypes.FULL;
            if (visibility === 'all')
                return this._visibilityTypes.PARTIAL;
        }
        return this._visibilityTypes.NONE;
    }
    _hideTooltip() {
        this._initializeContainer();
        this._clearContainer();
        this._toggleContainer(false);
    }
    _appendAltTooltipContainer(tooltipHTML) {
        const tooltipContainer = $(`<div class="${Utils.moduleName}-tooltip-container"></div>`);
        tooltipContainer.append(tooltipHTML);
        $('.game').append(tooltipContainer);
        return tooltipContainer;
    }
    async _getTooltipHTML(token) {
        const visibilityType = this._typeToShow(token);
        if (visibilityType === this._visibilityTypes.NONE)
            return;
        return await renderTemplate(Settings.templatePaths[0], this._getTooltipData(token, visibilityType));
    }
    async _handleTooltip(token, isHovering) {
        this._initializeContainer();
        if (!isHovering) {
            this._clearContainer();
            this._toggleContainer(false);
            return;
        }
        const tooltipHTML = await this._getTooltipHTML(token);
        this._appendToContainer(tooltipHTML);
        this._toggleContainer(true);
        this._positionTooltip(this._tooltipContainer, token);
    }
    async _handleAltTooltips(token, isHovering) {
        if (!isHovering)
            return;
        const tooltipHTML = await this._getTooltipHTML(token);
        const tooltipContainer = this._appendAltTooltipContainer(tooltipHTML);
        this._positionTooltip(tooltipContainer, token);
        this._altTooltipContainers.push(tooltipContainer);
    }
    async hoverTokenHook(token, isHovering) {
        if (!token?.actor)
            return;
        const isAltPressed = keyboard?.isDown('Alt');
        if (!isAltPressed && !this._wasTabDown) {
            return this._handleTooltip(token, isHovering);
        }
        const allowShowAlt = Settings.getSetting('showAllOnAlt');
        const showTooltipForHiddenTokens = Settings.getSetting('showTooltipForHiddenTokens');
        const isTokenHidden = token?.data?.hidden;
        if (!allowShowAlt || (isTokenHidden && !showTooltipForHiddenTokens))
            return;
        if (!isAltPressed) {
            return this._clearAltContainers();
        }
        if (isAltPressed) {
            this._wasTabDown = true;
            return this._handleAltTooltips(token, isHovering);
        }
    }
    hideTooltipOnHook() {
        this._hideTooltip();
        this._clearAltContainers();
    }
}
export default TooltipHandler.getInstance();
