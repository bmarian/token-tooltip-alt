import Settings from "./Settings.js";
import Utils from "./Utils.js";
class TooltipHandler {
    constructor() {
        this._tooltipContainer = null;
        this._visibilityTypes = { FULL: 'full', PARTIAL: 'partial', NONE: 'none' };
        this._iconPresets = Settings.getIconPresets();
        this._altTooltipContainers = [];
        this._wasTabDown = false;
    }
    static getInstance() {
        if (!TooltipHandler._instance)
            TooltipHandler._instance = new TooltipHandler();
        return TooltipHandler._instance;
    }
    _initializeContainer() {
        if (!this._tooltipContainer)
            this._tooltipContainer = $(`.${Utils.moduleName}-tooltip-container`);
        return this._tooltipContainer;
    }
    _toggleContainer(show) {
        this._tooltipContainer[show ? 'removeClass' : 'addClass']('hidden');
    }
    _clearContainer() {
        this._tooltipContainer.empty();
    }
    _clearAltContainers() {
        while (this._altTooltipContainers.length > 0) {
            const tooltipContainer = this._altTooltipContainers.pop();
            tooltipContainer.remove();
        }
    }
    _appendToContainer(content) {
        this._clearContainer();
        this._tooltipContainer.html(content);
    }
    _getTooltipPosition(token) {
        const tokenWT = token.worldTransform;
        return {
            left: tokenWT.tx + (token.width * tokenWT.a),
            // -5 comes from the token border when hovering, just makes the tooltip look nicer
            top: tokenWT.ty - 5,
            zIndex: token.zIndex,
            // Some extra styling to make it look nicer
            // @ts-ignore
            color: game?.user?.color,
        };
    }
    _positionTooltip(tooltipContainer, token) {
        const position = this._getTooltipPosition(token);
        tooltipContainer.css(position);
    }
    _appendSimpleStat(value, icon, statsArray) {
        if (!isNaN(value))
            statsArray.push({ value: `${value}`, icon });
    }
    _appendHPStat(values, icon, statsArray) {
        if (!(isNaN(values.HP) && isNaN(values.maxHP))) {
            const tempHP = values.tempHP > 0 ? `(${values.tempHP})` : '';
            const tempHPMax = values.tempHPMax > 0 ? `(${values.tempHPMax})` : '';
            const value = `${values.HP}${tempHP}/${values.maxHP}${tempHPMax}`;
            statsArray.push({ value, icon });
        }
    }
    // TODO: Rework this in a more generic function
    _getTooltipData(token, visibilityType) {
        const stats = [];
        const aData = token?.actor?.data?.data;
        const aAttr = aData?.attributes;
        const aSkills = aData?.skills;
        const HP = parseInt(aAttr?.hp?.value);
        const maxHP = parseInt(aAttr?.hp?.max);
        const tempHP = parseInt(aAttr?.hp?.temp) || 0;
        const tempHPMax = parseInt(aAttr?.hp?.tempmax) || 0;
        this._appendHPStat({ HP, maxHP, tempHP, tempHPMax }, this._iconPresets.HP, stats);
        const ac = parseInt(aAttr?.ac?.value);
        this._appendSimpleStat(ac, this._iconPresets.AC, stats);
        if (visibilityType === this._visibilityTypes.FULL) {
            const speed = parseInt(aAttr?.speed?.value);
            const passivesPerception = parseInt(aSkills?.prc?.passive);
            const passivesInvestigation = parseInt(aSkills?.inv?.passive);
            this._appendSimpleStat(speed, this._iconPresets.SPEED, stats);
            this._appendSimpleStat(passivesPerception, this._iconPresets.PASSIVE_PERCEPTION, stats);
            this._appendSimpleStat(passivesInvestigation, this._iconPresets.PASSIVE_INVESTIGATION, stats);
        }
        return { moduleName: Utils.moduleName, stats };
    }
    _typeToShow(token) {
        const visibility = Settings.getSetting('tooltipVisibility');
        if (game?.user?.isGM)
            return this._visibilityTypes.FULL;
        if (visibility !== 'gm') {
            if (token?.actor?.owner)
                return this._visibilityTypes.FULL;
            const isFriendly = token?.data?.disposition === CONST?.TOKEN_DISPOSITIONS?.FRIENDLY;
            const isObservable = token?.actor?.permission === CONST?.ENTITY_PERMISSIONS?.OBSERVER;
            if ((isFriendly || isObservable) && (visibility === 'friendly' || visibility === 'all'))
                return this._visibilityTypes.FULL;
            if (visibility === 'all')
                return this._visibilityTypes.PARTIAL;
        }
        return this._visibilityTypes.NONE;
    }
    _hideTooltip() {
        this._initializeContainer();
        this._clearContainer();
        this._toggleContainer(false);
    }
    _appendAltTooltipContainer(tooltipHTML) {
        const tooltipContainer = $(`<div class="${Utils.moduleName}-tooltip-container"></div>`);
        tooltipContainer.append(tooltipHTML);
        $('.game').append(tooltipContainer);
        return tooltipContainer;
    }
    async _handleTooltip(token, isHovering) {
        this._initializeContainer();
        if (!isHovering) {
            this._clearContainer();
            this._toggleContainer(false);
            return;
        }
        const visibilityType = this._typeToShow(token);
        if (visibilityType === this._visibilityTypes.NONE)
            return;
        const tooltipHTML = await renderTemplate(Settings.templatePath, this._getTooltipData(token, visibilityType));
        this._appendToContainer(tooltipHTML);
        this._toggleContainer(true);
        this._positionTooltip(this._tooltipContainer, token);
    }
    async _handleAltTooltips(token, isHovering) {
        if (!isHovering)
            return;
        const visibilityType = this._typeToShow(token);
        if (visibilityType === this._visibilityTypes.NONE)
            return;
        const tooltipHTML = await renderTemplate(Settings.templatePath, this._getTooltipData(token, visibilityType));
        const tooltipContainer = this._appendAltTooltipContainer(tooltipHTML);
        this._positionTooltip(tooltipContainer, token);
        this._altTooltipContainers.push(tooltipContainer);
    }
    async hoverTokenHook(token, isHovering) {
        if (!token?.actor)
            return;
        const allowShowAlt = Settings.getSetting('showAllOnAlt');
        const isAltPressed = keyboard?.isDown('Alt');
        if (!isAltPressed && !this._wasTabDown) {
            return this._handleTooltip(token, isHovering);
        }
        if (!allowShowAlt)
            return;
        if (!isAltPressed) {
            this._wasTabDown = false;
            return this._clearAltContainers();
        }
        if (isAltPressed) {
            this._wasTabDown = true;
            return this._handleAltTooltips(token, isHovering);
        }
    }
    hideTooltipOnHook() {
        this._hideTooltip();
        this._clearAltContainers();
    }
}
export default TooltipHandler.getInstance();
