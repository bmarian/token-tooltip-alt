import Utils from "./Utils.js";
class Settings {
    constructor() {
        this.templatePath = 'modules/token-tooltip-alt/templates/tooltip.hbs';
        this._iconPresets = {
            HP: 'fa-heart',
            AC: 'fa-shield-alt',
            SPEED: 'fa-shoe-prints',
            PASSIVE_PERCEPTION: 'fa-eye',
            PASSIVE_INVESTIGATION: 'fa-search'
        };
    }
    static getInstance() {
        if (!Settings._instance)
            Settings._instance = new Settings();
        return Settings._instance;
    }
    getSettings() {
        return [
            {
                key: "tooltipVisibility",
                settings: {
                    name: "Tooltip visibility",
                    hint: "This option determines which tokens display a tooltip when a player hovers over them.",
                    type: String,
                    scope: "world",
                    config: true,
                    restricted: true,
                    default: "gm",
                    choices: {
                        "gm": "GM Only",
                        "owned": "Owned Tokens",
                        "friendly": "Friendly Tokens",
                        "all": "All Tokens"
                    }
                },
            },
            {
                key: "showAllOnAlt",
                settings: {
                    name: "Show all tooltips on ALT",
                    hint: "Show tooltips for all tokens when holding alt. (super EXPERIMENTAL, might have a lot of bugs)",
                    type: Boolean,
                    scope: "world",
                    config: true,
                    restricted: true,
                    default: true,
                },
            },
        ];
    }
    getSetting(key) {
        return game?.settings?.get(Utils.moduleName, key);
    }
    registerSettings() {
        this.getSettings().forEach((setting) => {
            game?.settings?.register(Utils.moduleName, setting.key, setting.settings);
        });
    }
    getIconPresets() {
        return this._iconPresets;
    }
}
export default Settings.getInstance();
