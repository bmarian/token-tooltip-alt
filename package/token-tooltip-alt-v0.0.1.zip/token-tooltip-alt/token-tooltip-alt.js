import Init from "./module/Init.js";
import TooltipHandler from "./module/TooltipHandler.js";
Hooks.once('init', Init.initHook.bind(Init));
Hooks.once('canvasInit', Init.canvasInitHook.bind(Init));
Hooks.on('hoverToken', TooltipHandler.hoverTokenHook.bind(TooltipHandler));
Hooks.on('preUpdateToken', TooltipHandler.hideTooltipOnHook.bind(TooltipHandler));
Hooks.on('canvasPan', TooltipHandler.hideTooltipOnHook.bind(TooltipHandler));
Hooks.on('renderTokenHUD', TooltipHandler.hideTooltipOnHook.bind(TooltipHandler));
Hooks.on('deleteToken', TooltipHandler.hideTooltipOnHook.bind(TooltipHandler));
