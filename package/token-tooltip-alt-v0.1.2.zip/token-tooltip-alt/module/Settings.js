import Utils from "./Utils.js";
import SettingsEditor from "../apps/SettingsEditor.js";
class Settings {
    constructor() {
        this.templatePaths = [
            `modules/${Utils.moduleName}/templates/tooltip.hbs`,
            `modules/${Utils.moduleName}/templates/settings-editor-row.hbs`,
        ];
        this.settingKeys = {
            TOOLTIP_VISIBILITY: 'tooltipVisibility',
            SHOW_ALL_ON_ALT: 'showAllOnAlt',
            SHOW_TOOLTIP_FOR_HIDDEN_TOKENS: 'showTooltipForHiddenTokens',
            DISPLAY_NAMES_IN_TOOLTIP: 'displayNameInTooltip',
            TOOLTIP_ITEMS: 'tooltipItems',
        };
    }
    static getInstance() {
        if (!Settings._instance)
            Settings._instance = new Settings();
        return Settings._instance;
    }
    getSettings() {
        return [
            {
                key: "tooltipVisibility",
                settings: {
                    name: "Tooltip visibility",
                    hint: "This option determines which tokens display a tooltip when a player hovers over them.",
                    type: String,
                    scope: "world",
                    config: true,
                    restricted: true,
                    default: "gm",
                    choices: {
                        "gm": "GM only",
                        "owned": "Owned tokens",
                        "friendly": "Friendly tokens",
                        "all": "All tokens"
                    }
                },
            },
            {
                key: "showAllOnAlt",
                settings: {
                    name: "Show all tooltips on ALT",
                    hint: "Show tooltips for all tokens when holding alt. --EXPERIMENTAL--",
                    type: Boolean,
                    scope: "world",
                    config: true,
                    restricted: true,
                    default: true,
                },
            },
            {
                key: "showTooltipForHiddenTokens",
                settings: {
                    name: "Show tooltip for hidden tokens on ALT",
                    hint: "If enabled this will also show tooltips for hidden tokens.",
                    type: Boolean,
                    scope: "world",
                    config: true,
                    restricted: true,
                    default: false,
                },
            },
            {
                key: "displayNameInTooltip",
                settings: {
                    name: "Display token name",
                    hint: "Display the token name in the tooltip.",
                    type: Boolean,
                    scope: "world",
                    config: true,
                    restricted: true,
                    default: false,
                },
            },
            {
                key: "tooltipItems",
                settings: {
                    type: Object,
                    scope: "world",
                    restricted: true,
                    default: [
                        {
                            icon: 'fa-heart',
                            value: 'attributes.hp',
                        },
                        {
                            icon: 'fa-shield-alt',
                            value: 'attributes.ac.value',
                        },
                        {
                            icon: 'fa-shoe-prints',
                            value: 'attributes.speed.value',
                        },
                        {
                            icon: 'fa-eye',
                            value: 'skills.prc.passive',
                        },
                        {
                            icon: 'fa-search',
                            value: 'skills.inv.passive',
                        },
                    ],
                },
            },
        ];
    }
    _registerMenu() {
        game.settings.registerMenu(Utils.moduleName, 'settingsEditor', {
            name: 'Settings Editor',
            hint: "Edit what stats should be tracked.",
            label: 'Open settings editor',
            icon: "fas fa-edit",
            type: SettingsEditor,
            restricted: true,
        });
    }
    getSetting(key) {
        return game?.settings?.get(Utils.moduleName, key);
    }
    setSetting(key, data) {
        return game.settings.set(Utils.moduleName, key, data);
    }
    registerSettings() {
        this._registerMenu();
        this.getSettings().forEach((setting) => {
            game?.settings?.register(Utils.moduleName, setting.key, setting.settings);
        });
    }
}
export default Settings.getInstance();
